This is the github repository for my bachelor thesis.<br>
<br>
pip install . <br>
works for windows11 and ubuntu 22 <br>
if package is installed as UNKOWN upgrade pip and setuptools <br>